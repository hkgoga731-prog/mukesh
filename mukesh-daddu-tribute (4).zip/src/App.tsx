/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion, AnimatePresence } from "motion/react";
import { 
  Heart, 
  Users, 
  MapPin, 
  Award, 
  Instagram, 
  Calendar, 
  Droplets,
  ExternalLink,
  ChevronDown,
  Volume2,
  Loader2,
  Play,
  Pause
} from "lucide-react";
import { useState, useRef } from "react";
import { GoogleGenAI, Modality } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const SOCIAL_LINKS = [
  {
    name: "Rehan Chaudhary",
    url: "https://www.instagram.com/rehan_chaudhary_7627?igsh=MTBkOXA1ZmQwMTJvMg==",
  },
  {
    name: "Mukesh Daddu Official",
    url: "https://www.instagram.com/mukesh_daddu_official_9094?igsh=MTlwNHNsYXIwbnpvZA==",
  },
  {
    name: "Mukesh Dadu Official 88",
    url: "https://www.instagram.com/mukeshdadu_official88?igsh=cGZiczUyNXp6NGhn",
  },
  {
    name: "Ucharpi Public",
    url: "https://www.instagram.com/ucharpi_public?igsh=MTBsYzVqaXBuaGlvMA==",
  },
];

const GUJARATI_TRIBUTE_TEXT = "સોશિયલ મીડિયા રિપોર્ટ્સના આધારે, ગુજરાતના મહેસાણાના મુકેશ ચૌધરી (જેને ઘણીવાર દાદુ અથવા દદુ તરીકે ઓળખવામાં આવે છે) ચૌધરી/આંજણા સમુદાયમાં એક જાણીતા વ્યક્તિ હતા . તેઓ મહેસાણા પ્રદેશ સાથે સંકળાયેલા હતા અને તેમના અનુયાયીઓ સમુદાયના \"વાસ્તવિક નાયક\" અથવા \"સિંહ\" તરીકે જાણીતા હતા. અહેવાલો સૂચવે છે કે તેમનું અવસાન થયું છે, અને અનુયાયીઓ તેમના આત્માને શ્રદ્ધાંજલિ આપી રહ્યા છે.";

const SECTION_ANIMATION = {
  initial: { opacity: 0, y: 20 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.8 }
};

export default function App() {
  const [isGeneratingAudio, setIsGeneratingAudio] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioBufferSourceRef = useRef<AudioBufferSourceNode | null>(null);

  const handlePlayAudio = async () => {
    if (isPlaying) {
      if (audioBufferSourceRef.current) {
        audioBufferSourceRef.current.stop();
        audioBufferSourceRef.current = null;
      }
      setIsPlaying(false);
      return;
    }

    try {
      setIsGeneratingAudio(true);
      
      const response = await ai.models.generateContent({
        model: "gemini-3.1-flash-tts-preview",
        contents: [{ parts: [{ text: `Please read this tribute in a respectful, calm Gujarati voice: ${GUJARATI_TRIBUTE_TEXT}` }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Kore' },
            },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      
      if (base64Audio) {
        const binaryString = window.atob(base64Audio);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }

        // Gemini TTS returns 24kHz Mono PCM usually
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        audioContextRef.current = audioContext;

        // Convert Int16 PCM (binary) to Float32
        const int16Array = new Int16Array(bytes.buffer);
        const float32Array = new Float32Array(int16Array.length);
        for (let i = 0; i < int16Array.length; i++) {
          float32Array[i] = int16Array[i] / 32768.0;
        }

        const audioBuffer = audioContext.createBuffer(1, float32Array.length, 24000);
        audioBuffer.getChannelData(0).set(float32Array);

        const source = audioContext.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(audioContext.destination);
        source.onended = () => setIsPlaying(false);
        
        audioBufferSourceRef.current = source;
        source.start();
        setIsPlaying(true);
      }
    } catch (error) {
      console.error("Audio generation failed:", error);
    } finally {
      setIsGeneratingAudio(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FAFAFA] text-slate-900 selection:bg-orange-100 font-sans">
      {/* Background Subtle Pattern */}
      <div className="fixed inset-0 pointer-events-none opacity-5 mix-blend-multiply" 
           style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23000000' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2v-4h4v-2h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2v-4h4v-2H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")` }} 
      />

      {/* Hero Section */}
      <header className="relative h-screen flex items-center justify-center overflow-hidden bg-gradient-to-b from-slate-900 to-slate-800">
        <div className="absolute inset-0 opacity-40">
          {/* Overlay for depth */}
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-orange-500/10 via-transparent to-transparent" />
        </div>
        
        <div className="container mx-auto px-6 relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1 }}
            className="mb-8"
          >
            <div className="w-48 h-48 md:w-56 md:h-56 mx-auto rounded-full border-4 border-orange-400/30 p-2 bg-gradient-to-tr from-orange-400/20 to-transparent backdrop-blur-sm overflow-hidden mb-6 group transition-all">
               {/* Replace with actual image in production */}
               <div className="w-full h-full rounded-full bg-slate-700 flex items-center justify-center grayscale group-hover:grayscale-0 transition-all overflow-hidden relative">
                  <img 
                    src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=400" 
                    alt="Mukesh Daddu"
                    className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity duration-700"
                  />
                  <div className="absolute inset-0 bg-slate-900/20 flex items-end justify-center pb-6">
                    <span className="bg-orange-600/90 text-white text-[10px] px-3 py-1 rounded-full font-mono uppercase tracking-[0.2em] shadow-xl backdrop-blur-md border border-white/20">
                      સ્વ. મુકેશભાઈ
                    </span>
                  </div>
               </div>
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold text-white tracking-tight mb-4 font-serif">
              સ્વ. મુકેશભાઈ શંકરભાઈ ચૌધરી
            </h1>
            <div className="flex items-center justify-center gap-4 text-orange-400/80 font-mono text-sm tracking-widest uppercase mb-8">
              <span>20-04-1981</span>
              <span className="w-12 h-px bg-white/20" />
              <span>10-04-2026</span>
            </div>
            <p className="text-xl text-slate-300 font-light italic">
              Mukesh Daddu (Ucharpi)
            </p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 1 }}
            className="flex flex-col items-center gap-4"
          >
            <div className="h-px w-24 bg-orange-400/50 mb-4" />
            <p className="text-white/70 max-w-2xl text-lg leading-relaxed font-light">
              A fearless leader, a community protector, and a heart that beat for Mehsana.
            </p>
            <motion.div 
              animate={{ y: [0, 10, 0] }}
              transition={{ repeat: Infinity, duration: 3 }}
              className="mt-12 text-white/30"
            >
              <ChevronDown size={32} />
            </motion.div>
          </motion.div>
        </div>
      </header>

      {/* Legacy & Community */}
      <section className="py-24 bg-white border-y border-slate-100 relative">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div {...SECTION_ANIMATION}>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-50 text-orange-700 text-sm font-medium mb-6">
                <Users size={16} />
                <span>Community Pillar</span>
              </div>
              <h2 className="text-3xl md:text-4xl font-serif font-bold text-slate-900 mb-6 leading-tight">
                The <span className="text-orange-600">"Real Hero"</span> of Mehsana
              </h2>
              <div className="space-y-6 text-slate-600 leading-relaxed text-lg">
                <p>
                  Chaudhary Mukesh Daddu was more than just a name; he was a symbol of strength and unity for the 
                  <strong> Chaudhary/Anjana</strong> community. Known affectionately as <strong>"Daddu"</strong>, 
                  he was respected as a prominent leader and protector.
                </p>
                <div className="bg-slate-50 p-6 rounded-2xl border-l-4 border-orange-400 font-serif italic text-slate-800">
                  "સમુદાય વર્તુળોમાં તેમને વારંવાર 'સિંહ' અથવા 'વાસ્તવિક નાયક' જેવા સન્માનજનક ઉપનામો દ્વારા સંબોધવામાં આવતા હતા."
                </div>
                <p>
                  His influence extended deeply into rural Mehsana, Unjha, and Visnagar, where he was recognized as a vocal 
                  representative of his people and a guardian of their values.
                </p>
              </div>
            </motion.div>

            <motion.div 
              {...SECTION_ANIMATION}
              className="grid grid-cols-2 gap-4"
            >
              {[
                { label: "Community", value: "Chaudhary/Anjana", icon: Users },
                { label: "Nickname", value: "Lion (સિંહ)", icon: Award },
                { label: "Primary Base", value: "Mehsana, Ucharpi", icon: MapPin },
                { label: "Legacy", value: "Respect & Honor", icon: Heart },
              ].map((item, idx) => (
                <div key={idx} className="p-8 bg-slate-50 rounded-3xl hover:bg-orange-50 transition-colors group">
                  <item.icon className="text-orange-600 mb-4 group-hover:scale-110 transition-transform" size={24} />
                  <p className="text-xs uppercase tracking-widest text-slate-400 font-bold mb-1">{item.label}</p>
                  <p className="text-xl font-bold text-slate-800">{item.value}</p>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Special Event: Blood Donation */}
      <section className="py-24 bg-slate-900 text-white overflow-hidden relative">
        <div className="absolute right-0 top-0 w-1/3 h-full bg-orange-600/10 skew-x-12 translate-x-20" />
        
        <div className="container mx-auto px-6 relative z-10">
          <motion.div 
            {...SECTION_ANIMATION}
            className="text-center mb-16"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-orange-400 text-sm font-medium mb-6">
              <Calendar size={16} />
              <span>April 2026 Tribute</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6">A Legacy of <span className="text-orange-400">Giving</span></h2>
            <p className="text-slate-400 max-w-2xl mx-auto text-lg italic">
              "તેમના જન્મજયંતિ નિમિત્તે ઉચરપીમાં રક્તદાન શિબિરનું આયોજન કરવામાં આવ્યું હતું."
            </p>
          </motion.div>

          <div className="flex flex-col md:flex-row items-center justify-center gap-12">
            <div className="w-full md:w-1/2 flex justify-center">
              <motion.div 
                whileHover={{ scale: 1.05 }}
                className="relative p-12 bg-white/5 backdrop-blur-md rounded-[3rem] border border-white/10 text-center"
              >
                <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-orange-600 p-6 rounded-full shadow-xl">
                  <Droplets size={40} className="text-white" />
                </div>
                <div className="text-7xl font-bold text-orange-500 mb-2">951</div>
                <div className="text-2xl font-serif mb-4 uppercase tracking-widest text-slate-300">Units of Life</div>
                <p className="text-slate-400 leading-relaxed max-w-xs mx-auto">
                  A massive blood donation drive was held in Ucharpi on April 2026 to celebrate his life, 
                  where 951 units of blood were collected by his supporters.
                </p>
              </motion.div>
            </div>
          </div>
        </div>
      {/* Special Event: Blood Donation section ends around line 240 */}
      </section>

      {/* Audio Tribute Section */}
      <section className="py-24 bg-white border-b border-slate-100">
        <div className="container mx-auto px-6">
          <motion.div 
            {...SECTION_ANIMATION}
            className="max-w-4xl mx-auto bg-slate-50 rounded-[2.5rem] p-8 md:p-12 border border-slate-100 shadow-sm relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-orange-100/50 rounded-bl-full -mr-16 -mt-16" />
            
            <div className="flex flex-col md:flex-row gap-12 items-center">
              <div className="flex-1">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-100 text-orange-700 text-xs font-bold uppercase tracking-wider mb-6">
                  <Volume2 size={14} />
                  <span>Audio Tribute</span>
                </div>
                <h3 className="text-2xl font-serif font-bold text-slate-900 mb-6">
                  શ્રદ્ધાંજલિ સંદેશ (Gujarati Audio)
                </h3>
                <p className="text-slate-600 leading-relaxed text-lg mb-8 italic">
                  "{GUJARATI_TRIBUTE_TEXT}"
                </p>
                
                <button
                  onClick={handlePlayAudio}
                  disabled={isGeneratingAudio}
                  className="flex items-center gap-4 bg-orange-600 hover:bg-orange-700 text-white px-8 py-4 rounded-2xl font-bold transition-all disabled:opacity-50 disabled:cursor-wait group relative overflow-hidden shadow-lg shadow-orange-200"
                >
                  <span className="relative z-10 flex items-center gap-3">
                    {isGeneratingAudio ? (
                      <Loader2 className="animate-spin" size={20} />
                    ) : isPlaying ? (
                      <Pause size={20} />
                    ) : (
                      <Play size={20} />
                    )}
                    {isGeneratingAudio ? "Generating Audio..." : isPlaying ? "Pause Audio" : "Listen to Legacy"}
                  </span>
                  <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
                </button>
              </div>
              
              <div className="w-full md:w-64 flex justify-center">
                <div className="relative">
                  <div className={`w-48 h-48 rounded-full border-4 border-orange-200 flex items-center justify-center bg-white shadow-xl transition-all duration-500 ${isPlaying ? 'scale-110 shadow-orange-100' : ''}`}>
                    <div className={`absolute inset-0 rounded-full border-2 border-orange-500 border-dashed animate-spin-slow ${isPlaying ? 'opacity-100' : 'opacity-0'}`} style={{ animationDuration: '8s' }} />
                    <Heart size={48} className={`text-orange-500 transition-all duration-300 ${isPlaying ? 'scale-125 animate-pulse' : ''}`} />
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Social Links & Footer */}
      <footer className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h3 className="text-2xl font-serif font-bold text-slate-900 mb-4">Connect and Remember</h3>
            <p className="text-slate-500">Visit his official community and social media channels.</p>
          </div>

          <div className="flex flex-wrap justify-center gap-6 mb-16">
            {SOCIAL_LINKS.map((link, idx) => (
              <motion.a
                key={idx}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ y: -5 }}
                className="flex items-center gap-3 px-6 py-4 bg-slate-50 hover:bg-orange-600 hover:text-white rounded-2xl transition-all border border-slate-100 group shadow-sm hover:shadow-orange-200"
              >
                <Instagram size={24} className="text-orange-600 group-hover:text-white transition-colors" />
                <div>
                  <div className="text-xs uppercase tracking-widest text-slate-400 group-hover:text-white/70 font-bold">Instagram</div>
                  <div className="font-bold flex items-center gap-1">
                    {link.name} <ExternalLink size={12} />
                  </div>
                </div>
              </motion.a>
            ))}
          </div>

          <div className="border-t border-slate-100 pt-12 text-center text-slate-400 text-sm">
            <p className="mb-4">મા અર્બુદા ભાઈ ની આત્મા ને શાંતિ અને પરિવાર ને હિંમત આપે !</p>
            <p>&copy; 2026 Legacy Tribute - Chaudhary Mukesh Daddu (Ucharpi)</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
